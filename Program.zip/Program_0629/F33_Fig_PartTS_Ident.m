clear;clc;

%% Fig5 (B��C��D)
%Ƭ�ε��໥ʶ��/Ƭ�ε��Ա�Ԥ�⡢Ƭ�ε�StrengthԤ��
load E:\brainFingerprint\code\FCReliability\Results\Ident_AllFC_PartTS 
%load E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Gender_PartTS
% load E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_PicVoc_PartTS;
XVarNames = {'Mov1_1','Mov1_2','Mov1_3','Mov2_1','Mov2_2','Mov2_3','Mov3_1','Mov3_2','Mov3_3','Mov4_1','Mov4_2','Mov4_3'};
matrixplot(Acc, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'ColorBar', 'on');
