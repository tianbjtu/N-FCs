clear;clc;
ROI_NUM = 160;

load E:\brainFingerprint\code\FCReliability\Results\ICC_NSFC_PartTS;

%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;

NET_NUM = length(unique(NetNo)); 

ROI_No_New = [];
for i=1:NET_NUM
   NetNoTemp =  find(NetNo==i);%id
   len = length(NetNoTemp);
   halfLen = round(len/2);
   NetNoTemp1 = NetNoTemp(1:halfLen);
   NetNoTemp2 = NetNoTemp(halfLen+1:len);
   tempMatrix1 = ICC_NSFC_Mat(NetNoTemp1,NetNoTemp1);%��������Ϊ����
   tempMatrix2 = ICC_NSFC_Mat(NetNoTemp2,NetNoTemp2);
   sumColumn1 = sum(tempMatrix1);%value
    sumColumn2 = sum(tempMatrix2);
    
   [sumColumn1,id1]  = sort(sumColumn1);
   [sumColumn2,id2]  = sort(sumColumn2,'descend');
   NetNoTempNew = NetNoTemp1(id1);
   NetNoTempNew = [NetNoTempNew;NetNoTemp2(id2)];
   ROI_No_New = [ROI_No_New;NetNoTempNew];
end

ICC_NSFC_Mat = ICC_NSFC_Mat(ROI_No_New, ROI_No_New); 

imagesc(ICC_NSFC_Mat); colorbar(); caxis([0,1]),hold on;

%%
NetNoUnique = unique(NetNo); NetTmp = 1; 
for Count = 1 : ROI_NUM-1
    if(NetTmp < length(NetNoUnique))
        if(NetNo(ROI_No_New(Count)) == NetNoUnique(NetTmp) && NetNo(ROI_No_New(Count+1)) == NetNoUnique(NetTmp+1))
            Value = Count + 0.5;
            plot([0:160], Value * ones(1,161), 'c-', 'linewidth', 1);
            plot(Value * ones(1,161), [0:160], 'c-', 'linewidth', 1);
            NetTmp = NetTmp + 1;
        end
    end
end