clear;clc;

TS1_NO = [24:267, 289:508, 530:717, 738:801]+1; 
TS2_NO = [24:250, 271:529, 549:798]+1;
TS3_NO = [24:203, 225:408, 429:632, 654:795]+1;
TS4_NO = [24:256, 276:505, 526:781]+1;
load E:\brainFingerprint\code\FCReliability\Results\SubjInfo184_AgeGendIQ_200506;


load('E:\brainFingerprint\code\FCReliability\Results\HeadMotion1.mat'); 
SubjNoTmp = find (SubjInfo(:,13)); SubjNoUse = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16)); 
HM1 = HeadMotion(TS1_NO, SubjNoUse); HM1 = HM1';
load('E:\brainFingerprint\code\FCReliability\Results\HeadMotion2.mat'); 
SubjNoTmp = find (SubjInfo(:,14)); SubjNoUse = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16)); 
HM2 = HeadMotion(TS2_NO, SubjNoUse); HM2 = HM2';
load('E:\brainFingerprint\code\FCReliability\Results\HeadMotion3.mat');
SubjNoTmp = find (SubjInfo(:,15)); SubjNoUse = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,16)); 
HM3 = HeadMotion(TS3_NO, SubjNoUse); HM3 = HM3';
load('E:\brainFingerprint\code\FCReliability\Results\HeadMotion4.mat');
SubjNoTmp = find (SubjInfo(:,16)); SubjNoUse = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,13)); 
HM4 = HeadMotion(TS4_NO, SubjNoUse); HM4 = HM4';



%% HM 60 bin distribution
MeanHM = mean([HM1(:); HM2(:); HM3(:); HM4(:)]);
StdHM = std([HM1(:); HM2(:); HM3(:); HM4(:)]);
Step = (MeanHM + 3 * StdHM) / 60;
DividePoints = 0 : Step : MeanHM + 3*StdHM;


HM_Distribute = zeros (4, 60);

HM = HM1;
for SubjNo = 1 : size(HM, 1)
    for Tmp2 = 1 : 60
        A(Tmp2) = sum ( (DividePoints(Tmp2) <= HM(SubjNo, :)) .* (DividePoints(Tmp2+1) > HM(SubjNo, :)));
        HM_Distribute(1, SubjNo, Tmp2) = A(Tmp2) / length(TS1_NO);
    end    
end        

HM = HM2;
for SubjNo = 1 : size(HM, 1)
    for Tmp2 = 1 : 60
        A(Tmp2) = sum ( (DividePoints(Tmp2) <= HM(SubjNo, :)) .* (DividePoints(Tmp2+1) > HM(SubjNo, :)));
        HM_Distribute(2, SubjNo, Tmp2) = A(Tmp2) / length(TS2_NO);
    end    
end        

HM = HM3;
for SubjNo = 1 : size(HM, 1)
    for Tmp2 = 1 : 60
        A(Tmp2) = sum ( (DividePoints(Tmp2) <= HM(SubjNo, :)) .* (DividePoints(Tmp2+1) > HM(SubjNo, :)));
        HM_Distribute(3, SubjNo, Tmp2) = A(Tmp2) / length(TS3_NO);
    end    
end        

HM = HM4;
for SubjNo = 1 : size(HM, 1)
    for Tmp2 = 1 : 60
        A(Tmp2) = sum ( (DividePoints(Tmp2) <= HM(SubjNo, :)) .* (DividePoints(Tmp2+1) > HM(SubjNo, :)));
        HM_Distribute(4, SubjNo, Tmp2) = A(Tmp2) / length(TS4_NO);
    end    
end        

save 'E:\brainFingerprint\code\FCReliability\Results\HeadMotion_Distribution' 'HM_Distribute' 'HM3' 'HM2' 'HM1' 'HM4';
% HM_Distribute 4*178*60����



%% HM ident
Acc = zeros(4, 4);
for Tmp1 = 1 : 4
    for Tmp2 = 1 : 4 
        AccurateNum = 0;        
        CorrM1 = squeeze(HM_Distribute(Tmp1, :, :)); 
        CorrM2 = squeeze(HM_Distribute(Tmp2, :, :));
        
        for Tmp3 = 1 : size(HM_Distribute, 2)
            CorrTmp = CorrM1(Tmp3, :);           %TargetAcc
            r = corrcoef([CorrTmp; CorrM2]');    %Source
            MaxR = max(r(1, 2:end));
            if(MaxR == r(1, Tmp3+1)) 
                AccurateNum = AccurateNum + 1;             
            end
        end
        
        Acc(Tmp1, Tmp2) = AccurateNum/size(HM_Distribute, 2);
    end
end
Acc
(sum(Acc(:))-4)/12
save E:\brainFingerprint\code\FCReliability\Results\HeadMotion_IdentAcc Acc;