clear;clc;
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';

%%
load (strcat(OUTDIR, 'Movie1_TS160')); 
Corr =  nets_netmats(TS, 0, 'corr');        % covariance (with variances on diagonal)
Corr = 0.5 * log((1+Corr) ./ (1-Corr));
save (strcat(OUTDIR, 'Movie1_Corr160'), 'Corr'); %% CorrΪ184*25600����

%%
load (strcat(OUTDIR, 'Movie2_TS160'));  
Corr =  nets_netmats(TS, 0, 'corr');       
Corr = 0.5 * log((1+Corr) ./ (1-Corr));
save (strcat(OUTDIR, 'Movie2_Corr160'), 'Corr'); %% CorrΪ183*25600����


%%
load (strcat(OUTDIR, 'Movie3_TS160')); 
Corr =  nets_netmats(TS, 0, 'corr');       
Corr = 0.5 * log((1+Corr) ./ (1-Corr));
save (strcat(OUTDIR, 'Movie3_Corr160'), 'Corr'); %% CorrΪ179*25600����


%%
load (strcat(OUTDIR, 'Movie4_TS160')); 
Corr =  nets_netmats(TS, 0, 'corr');        
Corr = 0.5 * log((1+Corr) ./ (1-Corr));
save (strcat(OUTDIR, 'Movie4_Corr160'), 'Corr'); %% CorrΪ179*25600����