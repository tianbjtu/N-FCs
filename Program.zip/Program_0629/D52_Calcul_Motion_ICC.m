
%% Motion 
% ����ÿ����Ӱ����ƽ����ͷ����NSFC����ICC������֮��ICC��˵�������ICC����ͷ����� 
clear;clc;
ROI_NUM = 160;

load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj.mat; 
load E:\brainFingerprint\code\FCReliability\Results\HeadMotion_Distribution;
HM{1} = HM1;  HM{2} = HM2; HM{3} = HM3; HM{4} = HM4;


%% HM ICC
Mean_HM(:, 1) = mean(HM1, 2);
Mean_HM(:, 2) = mean(HM2, 2);
Mean_HM(:, 3) = mean(HM3, 2);
Mean_HM(:, 4) = mean(HM4, 2);
[ICC_MeanHM, LB_MeanHM, UB_MeanHM, F, df1, df2, p] = f_ICC(Mean_HM, '1-1', 0.05, 0);
ICC_MeanHM
save E:\brainFingerprint\code\FCReliability\Results\HeadMotion_ICC_MeanHM ICC_MeanHM LB_MeanHM UB_MeanHM;


%% HM vs NSFC : Unit-wise ICC 
for MovNo = 1 : 4
    for Tmp = 1 : size(CorrMat, 3)
        [ICC(Tmp), LB(Tmp), UB(Tmp), F, df1, df2, p] = f_ICC([squeeze(CorrMat(MovNo,:,Tmp))', mean([HM{MovNo}], 2)], '1-1', 0.05, 0);
        % squeeze(CorrMat(MovNo,:,Tmp))': 178*1 ������ĳ����Ӱĳ��NSFC������������ȡֵ
        % mean(HM{MovNo}, 2)��HM{MovNo}��178*T�������ֵΪ178*1ƽ��ͷ������
    end
    
%     ICC_NSFC_Mat = zeros(ROI_NUM, ROI_NUM) + eye(ROI_NUM);
%     LB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM) + eye(ROI_NUM);
%     UB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM) + eye(ROI_NUM);

    ICC_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
    LB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
    UB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
    Count = 0;
    for Tmp1 = 1 : ROI_NUM - 1
        for Tmp2 = Tmp1 + 1 : ROI_NUM
            Count = Count + 1;
            ICC_NSFC_Mat(Tmp1, Tmp2) = ICC(Count);  ICC_NSFC_Mat(Tmp2, Tmp1) = ICC(Count);
            LB_NSFC_Mat(Tmp1, Tmp2) = LB(Count);  LB_NSFC_Mat(Tmp2, Tmp1) = LB(Count);
            UB_NSFC_Mat(Tmp1, Tmp2) = UB(Count);  UB_NSFC_Mat(Tmp2, Tmp1) = UB(Count);
        end
    end
    ICC_Array_All(MovNo, :) = ICC;    UB_Array_All(MovNo, :) = UB;    LB_Array_All(MovNo, :) = LB;
    ICC_All(MovNo, :, :) = ICC_NSFC_Mat;    UB_All(MovNo, :, :) = UB_NSFC_Mat;    LB_All(MovNo, :, :) = LB_NSFC_Mat;
end
save E:\brainFingerprint\code\FCReliability\Results\HeadMotion_ICC_NSFC_MeanMotion_Unit ICC_All UB_All LB_All ICC_Array_All UB_Array_All LB_All;
