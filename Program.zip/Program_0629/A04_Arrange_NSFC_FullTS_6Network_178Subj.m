clear;clc;
ROINUM = 160; NetNum = 6;
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';


%%
load E:\brainFingerprint\code\FCReliability\Results\SubjInfo184_AgeGendIQ_200506;
SubjNoUse = find(SubjInfo(:,13) .* SubjInfo(:,14) .* SubjInfo(:,15) .* SubjInfo(:,16));
SampleSize = length(SubjNoUse);

%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;

%% Movie 1: 184 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,13));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
load (strcat(OUTDIR, 'Movie1_Corr160')); 
for Tmp1 = 1 : NetNum
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROINUM,ROINUM); 
        Mat(NetNo1, NetNo2) = 1; 
        Mat = Mat .* (tril(ones(ROINUM))-eye(ROINUM));
        FEAT_NO = find(Mat);
        CorrMat{1, Tmp1, Tmp2} = [Corr(SubjNoTmpP, FEAT_NO)];        
        %CorrMat��һ���±꣺��Ӱ��ţ��ڶ��������±�
        CorrMat_Mean{1, Tmp1, Tmp2} = mean(Corr(SubjNoTmpP, FEAT_NO)');        
        %CorrMat��һ���±꣺��Ӱ��ţ��ڶ��������±�
    end
end


%% Movie 2: 183 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,14));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
load (strcat(OUTDIR, 'Movie2_Corr160')); 
for Tmp1 = 1 : NetNum
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROINUM,ROINUM); 
        Mat(NetNo1, NetNo2) = 1; 
        Mat = Mat .* (tril(ones(ROINUM))-eye(ROINUM));
        FEAT_NO = find(Mat);
        CorrMat{2, Tmp1, Tmp2} = [Corr(SubjNoTmpP, FEAT_NO)];
        CorrMat_Mean{2, Tmp1, Tmp2} = mean(Corr(SubjNoTmpP, FEAT_NO)');  
    end
end

%% Movie 3: 179 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,15));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,16));
load (strcat(OUTDIR, 'Movie3_Corr160')); 
for Tmp1 = 1 : NetNum
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROINUM,ROINUM); 
        Mat(NetNo1, NetNo2) = 1; 
        Mat = Mat .* (tril(ones(ROINUM))-eye(ROINUM));
        FEAT_NO = find(Mat);
        CorrMat{3, Tmp1, Tmp2} = [Corr(SubjNoTmpP, FEAT_NO)];
        CorrMat_Mean{3, Tmp1, Tmp2} = mean(Corr(SubjNoTmpP, FEAT_NO)');  
    end
end


%% Movie 4: 179 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,16));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15));
load (strcat(OUTDIR, 'Movie4_Corr160')); %Corr 179*25600
for Tmp1 = 1 : NetNum
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);         
        Mat = zeros(ROINUM,ROINUM); 
        Mat(NetNo1, NetNo2) = 1; 
        Mat = Mat .* (tril(ones(ROINUM))-eye(ROINUM));
        FEAT_NO = find(Mat);
        CorrMat{4, Tmp1, Tmp2} = [Corr(SubjNoTmpP, FEAT_NO)];
        CorrMat_Mean{4, Tmp1, Tmp2} = mean(Corr(SubjNoTmpP, FEAT_NO)');  %����������֮�����ӵ�ƽ�����õ�178����
    end
end

save E:\brainFingerprint\code\FCReliability\Results\CorrMat_All4Mov_6Net_178Subj CorrMat CorrMat_Mean
%%
%CorrMatά��4*6*6 cell ������178*���������Ӧ������
%CorrMat_Mean 4*6*6 cell ������1*178�������������������������ƽ����