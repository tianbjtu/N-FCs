clear;clc;
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';

%% 1
load (strcat(OUTDIR, 'Movie1_TS160-Part1')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie1_Part1_Corr160'), 'Corr'); %% CorrΪ184*25600����

load (strcat(OUTDIR, 'Movie1_TS160-Part2')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie1_Part2_Corr160'), 'Corr'); %% CorrΪ184*25600����

load (strcat(OUTDIR, 'Movie1_TS160-Part3')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie1_Part3_Corr160'), 'Corr'); %% CorrΪ184*25600����

%% 2
load (strcat(OUTDIR, 'Movie2_TS160-Part1')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie2_Part1_Corr160'), 'Corr'); %% CorrΪ183*25600����

load (strcat(OUTDIR, 'Movie2_TS160-Part2')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie2_Part2_Corr160'), 'Corr');

load (strcat(OUTDIR, 'Movie2_TS160-Part3')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie2_Part3_Corr160'), 'Corr'); 


%% 3
load (strcat(OUTDIR, 'Movie3_TS160-Part1')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie3_Part1_Corr160'), 'Corr'); %% CorrΪ179*25600����

load (strcat(OUTDIR, 'Movie3_TS160-Part2')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie3_Part2_Corr160'), 'Corr'); 

load (strcat(OUTDIR, 'Movie3_TS160-Part3')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie3_Part3_Corr160'), 'Corr'); 


%% 4
load (strcat(OUTDIR, 'Movie4_TS160-Part1')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie4_Part1_Corr160'), 'Corr'); %% CorrΪ179*25600����

load (strcat(OUTDIR, 'Movie4_TS160-Part2')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie4_Part2_Corr160'), 'Corr'); 

load (strcat(OUTDIR, 'Movie4_TS160-Part3')); 
Corr =  nets_netmats(TS, 0, 'corr'); Corr = 0.5 * log((1+Corr) ./ (1-Corr));      
save (strcat(OUTDIR, 'Movie4_Part3_Corr160'), 'Corr'); 