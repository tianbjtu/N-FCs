clear;clc;
ROINUM = 160;
FEAT_NO = find(tril(ones(ROINUM))-eye(ROINUM));
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';

%%
load E:\brainFingerprint\code\FCReliability\Results\SubjInfo184_AgeGendIQ_200506;
SubjNoUse = find(SubjInfo(:,13) .* SubjInfo(:,14) .* SubjInfo(:,15) .* SubjInfo(:,16));
SampleSize = length(SubjNoUse);
CorrMat = zeros(12, SampleSize, length(FEAT_NO));
CorrMat160 = zeros(12, SampleSize, ROINUM, ROINUM);


%%
for MovNo = 1 : 4
    if MovNo == 1
        SubjNoTmp = find (SubjInfo(:,13));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
    elseif MovNo == 2
        SubjNoTmp = find (SubjInfo(:,14));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
    elseif MovNo == 3
        SubjNoTmp = find (SubjInfo(:,15));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,16));
    elseif MovNo == 4
        SubjNoTmp = find (SubjInfo(:,16));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,13));
    end
    
    for PartNo = 1 : 3
        load (strcat(OUTDIR, ls(strcat(OUTDIR, 'Movie', num2str(MovNo), '_Part', num2str(PartNo), '_Corr160.mat'))));          
        CorrMat(3*(MovNo-1)+PartNo, :, :) = [Corr(SubjNoTmpP, FEAT_NO)];
        A = Corr(SubjNoTmpP, :); A = reshape(A, [SampleSize, ROINUM, ROINUM]);
        CorrMat160(3*(MovNo-1)+PartNo, :, :, :) = A;
    end
end

%%
save E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_12Part_178Subj CorrMat CorrMat160
% CorrMat 12*178*12720
% CorrMat160 12*178*160*160