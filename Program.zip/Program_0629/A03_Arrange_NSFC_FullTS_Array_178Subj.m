clear;clc;
ROINUM = 160;
FEAT_NO = find(tril(ones(ROINUM))-eye(ROINUM));
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';


%%
load E:\brainFingerprint\code\FCReliability\Results\SubjInfo184_AgeGendIQ_200506;
SubjNoUse = find(SubjInfo(:,13) .* SubjInfo(:,14) .* SubjInfo(:,15) .* SubjInfo(:,16));
SampleSize = length(SubjNoUse);
CorrMat = zeros(4, SampleSize, length(FEAT_NO));
CorrMat160 = zeros(4, SampleSize, ROINUM, ROINUM);

%% Movie 1: 184 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,13));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
load (strcat(OUTDIR, 'Movie1_Corr160')); %% CorrΪ184*25600����
CorrMat(1, :, :) = [Corr(SubjNoTmpP, FEAT_NO)];
A = Corr(SubjNoTmpP, :); A = reshape(A, [length(SubjNoUse), ROINUM, ROINUM]);
CorrMat160(1, :, :, :) = A;


%% Movie 2: 183 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,14));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
load (strcat(OUTDIR, 'Movie2_Corr160')); %% CorrΪ183*25600����
CorrMat(2, :, :) = [Corr(SubjNoTmpP, FEAT_NO)];
A = Corr(SubjNoTmpP, :); A = reshape(A, [length(SubjNoUse), ROINUM, ROINUM]);
CorrMat160(2, :, :, :) = A;

%% Movie 3: 179 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,15));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,16));
load (strcat(OUTDIR, 'Movie3_Corr160')); %% CorrΪ179*25600����
CorrMat(3, :, :) = [Corr(SubjNoTmpP, FEAT_NO)];
A = Corr(SubjNoTmpP, :); A = reshape(A, [length(SubjNoUse), ROINUM, ROINUM]);
CorrMat160(3, :, :, :) = A;

%% Movie 4: 179 Subj --> 178 Subj
SubjNoTmp = find (SubjInfo(:,16));
SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15));
load (strcat(OUTDIR, 'Movie4_Corr160')); %% CorrΪ179*25600����
CorrMat(4, :, :) = [Corr(SubjNoTmpP, FEAT_NO)];
A = Corr(SubjNoTmpP, :); A = reshape(A, [length(SubjNoUse), ROINUM, ROINUM]);
CorrMat160(4, :, :, :) = A;

%%
save E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj CorrMat CorrMat160
% CorrMat 4*178*12720
% CorrMat160 4*178*160*160