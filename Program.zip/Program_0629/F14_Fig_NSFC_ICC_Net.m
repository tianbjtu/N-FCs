%% Fig2(B) 
% FC
load E:\brainFingerprint\code\FCReliability\Results\ICC_Net_FullTS.mat;
XVarNames = {'SubcN','SMN','FPN','DMN','TempN','OccN'};%Ӧ��д��������
matrixplot(ICC_NetMean_Mat, 'XVarNames',XVarNames,'YVarNames',XVarNames, 'ColorBar', 'on');

