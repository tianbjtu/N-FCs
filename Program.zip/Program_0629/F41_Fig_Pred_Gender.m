clear;clc;
% %Fig4��A�����Ա�Ԥ�����
%load E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Gender;%��Χ����[0,0.9]
%   load E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Strength %��Χ����[0,0.45]
%  XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
%  matrixplot(MeanR, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');

%��ROC���� Fig4��C��
load E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Gender;
load E:\brainFingerprint\code\FCReliability\Results\SubjInfo178_222Label_200507;

LabelTmp = SubjInfo(:, 2);
SubjNoUse = find(LabelTmp ~= -9999); Label = LabelTmp(SubjNoUse); SampleSize = length(Label);
Predicted1 = squeeze(Predicted(3,1,1,:));%Predicted 100*4*4*178
%axis([0 1 0 1]);
plotroc(Label',Predicted1');
auc = AUC(Label,Predicted1);
title(strcat('ROC Curve (AUC =',num2str(auc,'%0.2f'),')'),'fontsize',15, 'fontname', 'arial', 'fontweight', 'bold');
box on;
set(gca,'XTick',[0 : 0.1: 1]); 
set(gca,'XTickLabel',[0 : 0.1 : 1]);

set(gca, 'fontsize',15, 'fontname', 'arial', 'fontweight', 'bold','Linewidth',2);

% %����״ Fig4��E��
% MAX_Y = 1500;
% 
% load E:\brainFingerprint\code\FCReliability\Results\Pred_Perm5000_PLSR160ROI_Gender R ; %5000��4*4��ֻȡ���꣨1,1������ǧ������
% load E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Gender MeanR;
% Rtrue = MeanR(1,1);
% Rtrue = 0.83;
% 
% R_Perm = squeeze(R(:,1,1));
% Rmax = max(R_Perm);
% Rmin = min(R_Perm);
% 
% % A = [-0.22 : 0.02 : 0.52];
% A = [0.32 : 0.03 : 0.86]; %%-----
% 
% for Tmp = 1 : length(A)
%     ACC_YY(Tmp) = sum ((R_Perm>=A(Tmp)-0.03) .* (R_Perm<A(Tmp))); %%-----
% end    
% 
% figure('Position',[100 200 800 800]);box on; hold on;grid on; axis([0.32 0.86 0 MAX_Y]); 
% set(gcf, 'color', 'white'); 
% set(gca, 'color', 'white', 'LineWidth',2, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% 
% h = bar(A-0.015, ACC_YY, 0.9, 'FaceColor',[0.55 0.55 0.55], 'LineWidth',2);
% set(gca,'XTick',A); 
% set(gca,'XTickLabel',[]);
% set(gca,'YTick',[0 : 100: MAX_Y]); 
% set(gca,'YTickLabel',[0 : 100 : MAX_Y]);
% % for Tmp = 1 : length(A)
% %     if ACC_YY(Tmp)>=100
% %         text(A(Tmp)-0.027, ACC_YY(Tmp)+19, num2str(ACC_YY(Tmp)), 'fontsize',9, 'fontname', 'arial', 'fontweight', 'bold'); % 'bold'
% %     elseif ACC_YY(Tmp)>0
% %         text(A(Tmp)-0.02, ACC_YY(Tmp)+19, num2str(ACC_YY(Tmp)), 'fontsize',9, 'fontname', 'arial', 'fontweight', 'bold');
% %     end
% % end
% 
% for Tmp = 1 : 2: length(A)
%     for i = [0.38 : 0.03 : 0.89]
%         if abs(A(Tmp)- i) < 10e-6
%             %data = A(Tmp)*100;
%             data = A(Tmp);
%             %str = [num2str(data,'%4.2f'),]
%             str = strcat(num2str(data*100,'%4.0f'),'%')
%             text(A(Tmp)-0.016,-35, str, 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
%         end
%     end
% end
% 
%     
% %     if(A(Tmp)<-0.03)
% %         text(A(Tmp)-0.015, -2, strcat('R',num2str(A(Tmp))), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% %     elseif (A(Tmp)>0.03)
% %         text(A(Tmp)-0.015, -2, strcat('R+',num2str(A(Tmp))), 'fontsize',14, 'fontname', 'arial', 'fontweight', 'bold');
% %     else        
% %         text(A(Tmp)-0.005, -2, 'R', 'fontsize',12, 'fontname', 'arial', 'fontweight', 'bold');
% %     end
% 
% plot(Rtrue*ones(1,length(0.2:0.1:MAX_Y-0.2)), [0.2:0.1:MAX_Y-0.2], 'r.', 'LineWidth',2)
% 
% %xlabel('Correlations Based on 500 Permutations', 'FontSize',19, 'fontname', 'arial', 'fontweight', 'bold', 'Position', [-0.6, -3.9]);
% ylabel('Number of Classification Rates', 'FontSize',15, 'fontname', 'arial', 'fontweight', 'bold'); 
% %xlabel('Correlation between the Estimated and Permuted Chronological Age', 'FontSize',16, 'fontname', 'arial', 'fontweight', 'bold'); 



