clear;clc;

clear;clc;
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';
TS1_NO1 = [24:267]+1; 
TS1_NO2 = [289:508]+1; 
TS1_NO3 = [530:717]+1; 
TS2_NO1 = [24:250]+1;
TS2_NO2 = [271:529]+1;
TS2_NO3 = [549:798]+1;
TS3_NO1 = [24:203]+1;
TS3_NO2 = [225:408]+1;
TS3_NO3 = [429:632]+1;
TS4_NO1 = [24:256]+1;
TS4_NO2 = [276:505]+1;
TS4_NO3 = [526:781]+1;


%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM1'; %%
load(INFile); Data = dataM1;  %% dataM1: 160*921*184����
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.DD = [1 : size(Data, 1)];
TS.UNK = []; 
%--------
Len = length(TS1_NO1); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS1_NO1, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie1_TS160-Part1'), 'TS');  %%TS�ṹ�壬����TS.ts Ϊ44896��160 ��44896=184*244�� 
%--------
Len = length(TS1_NO2); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS1_NO2, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie1_TS160-Part2'), 'TS');  %%%
%--------
Len = length(TS1_NO3); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS1_NO3, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie1_TS160-Part3'), 'TS');  %%%


%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM2'; %%
load(INFile); Data = dataM2;  %%
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.DD = [1 : size(Data, 1)];
TS.UNK = []; 
%--------
Len = length(TS2_NO1); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS2_NO1, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie2_TS160-Part1'), 'TS');  %%%
%--------
Len = length(TS2_NO2); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS2_NO2, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie2_TS160-Part2'), 'TS');  %%%
%--------
Len = length(TS2_NO3); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS2_NO3, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie2_TS160-Part3'), 'TS');  %%%



%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM3'; %%
load(INFile); Data = dataM3;  %%
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.DD = [1 : size(Data, 1)];
TS.UNK = []; 
%--------
Len = length(TS3_NO1); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS3_NO1, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie3_TS160-Part1'), 'TS');  %%%
%--------
Len = length(TS3_NO2); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS3_NO2, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie3_TS160-Part2'), 'TS');  %%%
%--------
Len = length(TS3_NO3); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS3_NO3, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie3_TS160-Part3'), 'TS');  %%%



%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM4'; %%
load(INFile); Data = dataM4;  %%
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.DD = [1 : size(Data, 1)];
TS.UNK = []; 
%--------
Len = length(TS4_NO1); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS4_NO1, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie4_TS160-Part1'), 'TS');  %%%
%--------
Len = length(TS4_NO2); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS4_NO2, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie4_TS160-Part2'), 'TS');  %%%
%--------
Len = length(TS4_NO3); %%%
TS.NtimepointsPerSubject=Len; TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;                     
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS4_NO3, Tmp))';  %%%
end
save (strcat(OUTDIR, 'Movie4_TS160-Part3'), 'TS');  %%%
