%matrixplot ��ɫ��Ĭ��
clear;clc;
ROI_NUM = 160;

%% Fig1(B��D��F) 
%NSFC
%load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj.mat; % CorrMat 4*178*12720 CorrMat160 4*178*160*160
%PartFC
load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_12Part_178Subj

MovNum = size(CorrMat160,1);

for Tmp1 = 1 : MovNum
    for Tmp2 = 1 : size(CorrMat160, 2)
        CorrMat160New (Tmp1, Tmp2, :, :) = reshape(squeeze(CorrMat160(Tmp1, Tmp2, :)), ROI_NUM, ROI_NUM);
    end
end

%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;
NET_NUM = length(unique(NetNo));

%%
%����Խ��߿��ֵʱ�����Խ���Ԫ��,ֵΪ0���������Ӱ��
CorrNetMean = zeros(NET_NUM, NET_NUM);
for Tmp = 1 : NET_NUM
    for Tmp2 = 1 : Tmp                     
        A = CorrMat160New(:, :, NetNo==Tmp, find(NetNo==Tmp2));
        if(Tmp == Tmp2)
            CorrNetMean(Tmp, Tmp2) = sum(A(:))/((length(find(NetNo==Tmp))^2 - length(find(NetNo==Tmp)))*MovNum*178)
        else     
            CorrNetMean(Tmp, Tmp2) = mean(A(:));
        end
    end
end

% %%
% %�����ֵ������ƽ��
% load E:\brainFingerprint\code\FCReliability\Results\NSFCdiffPartNSFCOriginal.mat

%��AP����Ļ���
% load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
% NetNo = ROI_160;
% NET_NUM = length(unique(NetNo));
% CorrNetMean = zeros(NET_NUM, NET_NUM);
% for Tmp = 1 : NET_NUM
%     for Tmp2 = 1 : Tmp                     
%         A = CorrAllTmp(NetNo==Tmp, NetNo==Tmp2);
%         if(Tmp == Tmp2)
%             CorrNetMean(Tmp, Tmp2) = sum(A(:))/(length(find(NetNo==Tmp))^2 - length(find(NetNo==Tmp)));
%         else     
%             CorrNetMean(Tmp, Tmp2) = mean(A(:));
%         end
%     end
% end
% CorrNetMean = roundn(CorrNetMean, -2);
%%
XVarNames = {'SubcN','SMN','FPN','DMN','TempN','OccN'};
matrixplot(CorrNetMean, 'XVarNames',XVarNames,'YVarNames',XVarNames,'ColorBar','on'); 