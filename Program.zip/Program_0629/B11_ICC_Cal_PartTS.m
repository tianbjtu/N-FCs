clear;clc;
ROI_NUM = 160; 

load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_12Part_178Subj.mat; 


%% NSFC 
for Tmp = 1 : size(CorrMat, 3)
    [ICC_NSFC(Tmp), LB_NSFC(Tmp), UB_NSFC(Tmp), F_NSFC(Tmp), df1, df2, p_NSFC(Tmp)] = f_ICC(squeeze(CorrMat(:,:,Tmp))', '1-1', 0.05, 0);%CorrMat 12*178*12720���Ž�ȥ178*12
end

% ICC_NSFC_Mat = zeros(ROI_NUM, ROI_NUM) + eye(ROI_NUM);
% LB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM) + eye(ROI_NUM);
% UB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM) + eye(ROI_NUM);
ICC_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
LB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);
UB_NSFC_Mat = zeros(ROI_NUM, ROI_NUM);

Count = 0;
for Tmp1 = 1 : ROI_NUM-1
    for Tmp2 = Tmp1 + 1 : ROI_NUM
        Count = Count + 1;
        ICC_NSFC_Mat(Tmp1, Tmp2) = ICC_NSFC(Count);
        ICC_NSFC_Mat(Tmp2, Tmp1) = ICC_NSFC(Count);
        LB_NSFC_Mat(Tmp1, Tmp2) = LB_NSFC(Count);
        LB_NSFC_Mat(Tmp2, Tmp1) = LB_NSFC(Count);
        UB_NSFC_Mat(Tmp1, Tmp2) = UB_NSFC(Count);
        UB_NSFC_Mat(Tmp2, Tmp1) = UB_NSFC(Count);
    end
end

save E:\brainFingerprint\code\FCReliability\Results\ICC_NSFC_PartTS ICC_NSFC LB_NSFC UB_NSFC ICC_NSFC_Mat LB_NSFC_Mat UB_NSFC_Mat;
% ICC_NSFC LB_NSFC UB_NSFC��1*12720����
% ICC_NSFC_Mat LB_NSFC_Mat UB_NSFC_Mat��160*160����


%% Network
%--���������network��ICC�ľ�ֵ��ÿ������21����ֵ��
%--���������������������õ���ICC_NSFC_Mat
%--���NetMean_ICC_Mat������NetMean���ICC

%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;
NET_NUM = length(unique(NetNo)); 

for Tmp1 = 1 : NET_NUM
    for Tmp2 = 1 : Tmp1
        NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2);
        Mat = zeros(ROI_NUM, ROI_NUM); 
        Mat(NetNo1, NetNo2) = 1; 
        Mat = Mat .* (tril(ones(ROI_NUM)) - eye(ROI_NUM));
        FEAT_NO = find(Mat);       
        
        ICC_NetMean_Mat(Tmp1, Tmp2) = mean(ICC_NSFC_Mat(FEAT_NO));
        LB_Net(Tmp1, Tmp2) = mean(LB_NSFC_Mat(FEAT_NO));
        UB_Net(Tmp1, Tmp2) = mean(UB_NSFC_Mat(FEAT_NO));
    end
end

save E:\brainFingerprint\code\FCReliability\Results\ICC_Net_PartTS ICC_NetMean_Mat LB_Net UB_Net;
% ICC_NetMean_Mat��NET_NUM * NET_NUM����
% LB_Net UB_Net��ͬ��


%% Global
ICC_Global = mean(ICC_NSFC);
LB_Glob = mean(LB_NSFC);
UB_Glob = mean(UB_NSFC);
save E:\brainFingerprint\code\FCReliability\Results\ICC_Glob_PartTS ICC_Global LB_Glob UB_Glob;
% ICC_Glob LB_Glob UB_Glob���Ǳ���