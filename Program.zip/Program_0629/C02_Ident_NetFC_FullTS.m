clear;clc;

load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj.mat;
% CorrMat160��4*178*160*160����
SubjNum = size(CorrMat160, 2);

%%
%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;
NET_NUM = length(unique(NetNo)); 

%% 
Acc = zeros(NET_NUM, NET_NUM, 4, 4);
for Net1 = 1 : NET_NUM;
    for Net2 = 1 : Net1
        
        for Mov1 = 1 : 4
            for Mov2 = 1 : 4 
                AccurateNum = 0;
                CorrM1p = squeeze(CorrMat160(Mov1, :, find(NetNo==Net1), find(NetNo==Net2)));
                CorrM2p = squeeze(CorrMat160(Mov2, :, find(NetNo==Net1), find(NetNo==Net2)));
                                
                %-----NSFC����ת��������
                CorrM1 = []; CorrM2 = [];
                if Net1 == Net2
                    FeatNo = find(tril(ones(sum(NetNo==Net1))) - eye(sum(NetNo==Net1)));
                    for Tmp = 1 : SubjNum
                        A = squeeze(CorrM1p(Tmp, :, :)); CorrM1(Tmp, :) = A(FeatNo);
                        A = squeeze(CorrM2p(Tmp, :, :)); CorrM2(Tmp, :) = A(FeatNo);
                    end
                else
                    for Tmp = 1 : SubjNum
                        A = squeeze(CorrM1p(Tmp, :, :)); CorrM1(Tmp, :) = A(:);
                        A = squeeze(CorrM2p(Tmp, :, :)); CorrM2(Tmp, :) = A(:);
                    end
                end                
                
                % -------ָ��ʶ��
                for Tmp3 = 1 : SubjNum
                    CorrTmp = CorrM1(Tmp3, :);           %Target
                    r = corrcoef([CorrTmp; CorrM2]');    %Source
                    MaxR = max(r(1, 2:end));
                    if(MaxR == r(1, Tmp3+1)) 
                        AccurateNum = AccurateNum + 1;             
                    end
                end
                Acc(Net1, Net2, Mov1, Mov2) = AccurateNum / SubjNum;
            end
        end       
        
    end
end

% Acc: NET_NUM * NET_NUM * 4 * 4����
save E:\brainFingerprint\code\FCReliability\Results\Ident_NetFC_FullTS Acc;
