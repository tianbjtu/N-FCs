%% Fig6 ͷ������ʶ��
clear;clc;
load E:\brainFingerprint\code\FCReliability\Results\HeadMotion_IdentAcc;
XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
matrixplot(Acc, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');
