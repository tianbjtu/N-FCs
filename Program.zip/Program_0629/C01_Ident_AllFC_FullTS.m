clear;clc;

load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj;
% CorrMat 4*178*12720
SubjNum = size(CorrMat, 2);

%% 
Acc = zeros(4, 4);
for Tmp1 = 1 : 4
    for Tmp2 = 1 : 4 
        AccurateNum = 0;        
        CorrM1 = squeeze(CorrMat(Tmp1, :, :)); 
        CorrM2 = squeeze(CorrMat(Tmp2, :, :));
        
        for Tmp3 = 1 : SubjNum
            CorrTmp = CorrM1(Tmp3, :);           %Target
            r = corrcoef([CorrTmp; CorrM2]');    %Source
            MaxR = max(r(1, 2:end));
            if(MaxR == r(1, Tmp3+1)) 
                AccurateNum = AccurateNum + 1;             
            end
        end
        
        Acc(Tmp1, Tmp2) = AccurateNum/SubjNum;
    end
end

% Acc�������ʽ һ����Target һ����Source
save E:\brainFingerprint\code\FCReliability\Results\Ident_AllFC_FullTS Acc;
