clear;clc;
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';
TS1_NO = [24:267, 289:508, 530:717, 738:801]+1; 
TS2_NO = [24:250, 271:529, 549:798]+1;%736
TS3_NO = [24:203, 225:408, 429:632, 654:795]+1;%710
TS4_NO = [24:256, 276:505, 526:781]+1;


%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM1'; %%
Len = length(TS1_NO);    %%
load(INFile);   %% dataM1: 160*921*184����
Data = dataM1;  %%
TS.NtimepointsPerSubject=Len; 
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;
TS.DD = [1 : size(Data, 1)];
TS.UNK = [];                      
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS1_NO, Tmp))';  %%
end
save (strcat(OUTDIR, 'Movie1_TS160'), 'TS');  %%TS�ṹ�壬����TS.ts Ϊ131744��160 ��131744=184*716�� 


%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM2'; %%
Len = length(TS2_NO);    %%
load(INFile); %% dataM1: 160*918*183����
Data = dataM2;  %%
TS.NtimepointsPerSubject=Len; 
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;
TS.DD = [1 : size(Data, 1)];
TS.UNK = [];                      
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS2_NO, Tmp))';  %%
end
save (strcat(OUTDIR, 'Movie2_TS160'), 'TS');  %%



%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM3'; %%
Len = length(TS3_NO);    %%
load(INFile); %% dataM1: 160*915*179����
Data = dataM3;  %%
TS.NtimepointsPerSubject=Len; 
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;
TS.DD = [1 : size(Data, 1)];
TS.UNK = [];                      
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS3_NO, Tmp))';  %%
end
save (strcat(OUTDIR, 'Movie3_TS160'), 'TS');  %%



%%
INFile = 'E:\brainFingerprint\code\FCReliability\Results\dataM4'; %%
Len = length(TS4_NO);    %%
load(INFile); %% dataM1: 160*901*179����
Data = dataM4;  %%
TS.NtimepointsPerSubject=Len; 
TS.ts = [];
TS.tr = 1;
TS.Nsubjects = size(Data, 3);
TS.Nnodes =  size(Data, 1);
TS.NnodesOrig = size(Data, 1);
TS.Ntimepoints = TS.Nsubjects * TS.NtimepointsPerSubject;
TS.DD = [1 : size(Data, 1)];
TS.UNK = [];                      
for Tmp = 1 : TS.Nsubjects
    TS.ts((Tmp-1)*Len+1 : Tmp*Len, :) = squeeze(Data(:, TS4_NO, Tmp))';  %%
end
save (strcat(OUTDIR, 'Movie4_TS160'), 'TS');  %%
