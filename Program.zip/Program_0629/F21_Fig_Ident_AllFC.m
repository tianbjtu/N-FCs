% %% Fig3(A)
%ʶ�������
clear;clc;
load E:\brainFingerprint\code\FCReliability\Results\Ident_AllFC_FullTS;
XVarNames = {'Mov1','Mov2','Mov3','Mov4'};
matrixplot(Acc, 'XVarNames', XVarNames, 'YVarNames', XVarNames, 'FillStyle', 'Fill', 'ColorBar', 'on');


