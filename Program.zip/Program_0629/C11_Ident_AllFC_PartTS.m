clear;clc;
load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_12Part_178Subj.mat
% CorrMat 12*178*12720
SubjNum = size(CorrMat, 2);MovNum = size(CorrMat, 1);

%% 
Acc = zeros(MovNum, MovNum);
for Tmp1 = 1 : MovNum
    for Tmp2 = 1 : MovNum 
        AccurateNum = 0;        
        CorrM1 = squeeze(CorrMat(Tmp1, :, :)); 
        CorrM2 = squeeze(CorrMat(Tmp2, :, :));
        
        for Tmp3 = 1 : SubjNum
            CorrTmp = CorrM1(Tmp3, :);           %Target
            r = corrcoef([CorrTmp; CorrM2]');    %Source
            MaxR = max(r(1, 2:end));
            if(MaxR == r(1, Tmp3+1)) 
                AccurateNum = AccurateNum + 1;             
            end
        end
        
        Acc(Tmp1, Tmp2) = AccurateNum/SubjNum;
    end
end

% Acc��12*12����
save E:\brainFingerprint\code\FCReliability\Results\Ident_AllFC_PartTS Acc;