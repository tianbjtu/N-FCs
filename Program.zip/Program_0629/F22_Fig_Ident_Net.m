%% Fig3(B) 
clear;
load E:\brainFingerprint\code\FCReliability\Results\Ident_NetFC_FullTS;

% for Tmp1 = 1 : 6
%     for Tmp2 = 1 : Tmp1
%         AccNew((Tmp1-1)*4+1:Tmp1*4, (Tmp2-1)*4+1:Tmp2*4) = Acc(Tmp1, Tmp2, :, :);
%     end
% end

AccNew = zeros(6,6);
for Tmp1 = 1 : 6
    for Tmp2 = 1 : Tmp1
        A = ones(4,4) - eye(4,4);
        B = A.*squeeze(Acc(Tmp1, Tmp2, :, :));
        AccNew(Tmp1,Tmp2) = sum(B(:))/12;
    end
end
XVarNames = {'SubcN','SMN','FPN','DMN','TempN','OccN'};
matrixplot(AccNew,'XVarNames',XVarNames,'YVarNames',XVarNames,'ColorBar','on');