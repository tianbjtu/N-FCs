clear;clc;
ROINUM = 160; NetNum = 6;
FEAT_NO = find(tril(ones(ROINUM))-eye(ROINUM));
OUTDIR = 'E:\brainFingerprint\code\FCReliability\Results\';

%%
load E:\brainFingerprint\code\FCReliability\Results\SubjInfo184_AgeGendIQ_200506;
SubjNoUse = find(SubjInfo(:,13) .* SubjInfo(:,14) .* SubjInfo(:,15) .* SubjInfo(:,16));
SampleSize = length(SubjNoUse);

%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;

%%
for MovNo = 1 : 4
    if MovNo == 1
        SubjNoTmp = find (SubjInfo(:,13));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
    elseif MovNo == 2
        SubjNoTmp = find (SubjInfo(:,14));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,16));
    elseif MovNo == 3
        SubjNoTmp = find (SubjInfo(:,15));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,13) .* SubjInfo(SubjNoTmp,16));
    elseif MovNo == 4
        SubjNoTmp = find (SubjInfo(:,16));
        SubjNoTmpP = find (SubjInfo(SubjNoTmp,14) .* SubjInfo(SubjNoTmp,15) .* SubjInfo(SubjNoTmp,13));
    end
    
    for PartNo = 1 : 3
        load (strcat(OUTDIR, ls(strcat(OUTDIR, 'Movie', num2str(MovNo), '_Part', num2str(PartNo), '_Corr160.mat')))); 
        
        for Tmp1 = 1 : NetNum
            for Tmp2 = 1 : Tmp1
                NetNo1 = find(NetNo == Tmp1); NetNo2 = find(NetNo == Tmp2); 
                Mat = zeros(ROINUM,ROINUM); 
                Mat(NetNo1, NetNo2) = 1; 
                Mat = Mat .* (tril(ones(ROINUM))-eye(ROINUM));
                FEAT_NO = find(Mat);
                CorrMat{3*(MovNo-1)+PartNo, Tmp1, Tmp2} = [Corr(SubjNoTmpP, FEAT_NO)];
                %CorrMat��һ���±꣺��ӰƬ�α�ţ���Mov1_1 2 3����Mov2_1 2 3��
                %�ڶ��������±�
                CorrMat_Mean{3*(MovNo-1)+PartNo, Tmp1, Tmp2} = mean(Corr(SubjNoTmpP, FEAT_NO)');
            end
        end        
    end
end

%%
save E:\brainFingerprint\code\FCReliability\Results\CorrMat_All4Mov_12Part_6Net_178Subj CorrMat CorrMat_Mean
%CorrMat 12*6*6 cell CorrMat_Mean 12*6*6 cell