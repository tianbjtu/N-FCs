ROI_NUM = 160;

%% Fig2(A) 
load E:\brainFingerprint\code\FCReliability\Results\ICC_NSFC_FullTS.mat;

%%
%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;
NET_NUM = length(unique(NetNo));

ROI_No_New = [];
for i=1:NET_NUM
   NetNoTemp =  find(NetNo==i);%id
   len = length(NetNoTemp);
   halfLen = round(len/2);
   NetNoTemp1 = NetNoTemp(1:halfLen);
   NetNoTemp2 = NetNoTemp(halfLen+1:len);
   tempMatrix1 = ICC_NSFC_Mat(NetNoTemp1,NetNoTemp1);%��������Ϊ����
   tempMatrix2 = ICC_NSFC_Mat(NetNoTemp2,NetNoTemp2);
   sumColumn1 = sum(tempMatrix1);%value
    sumColumn2 = sum(tempMatrix2);
    
   [sumColumn1,id1]  = sort(sumColumn1);
   [sumColumn2,id2]  = sort(sumColumn2,'descend');
   NetNoTempNew = NetNoTemp1(id1);
   NetNoTempNew = [NetNoTempNew;NetNoTemp2(id2)];
   ROI_No_New = [ROI_No_New;NetNoTempNew];
end

ICC_NSFC_Mat = ICC_NSFC_Mat(ROI_No_New, ROI_No_New); 
imagesc(ICC_NSFC_Mat); colorbar();caxis([-0.1,0.9]);  hold on;

%%
NetNoUnique = unique(NetNo); NetTmp = 1; 
for Count = 1 : ROI_NUM-1
    if(NetTmp < length(NetNoUnique))
        if(NetNo(ROI_No_New(Count)) == NetNoUnique(NetTmp) && NetNo(ROI_No_New(Count+1)) == NetNoUnique(NetTmp+1))
            Value = Count + 0.5;
            %plot([0:160], Value * ones(1,161), 'c-', 'linewidth', 1);
            %plot(Value * ones(1,161), [0:160], 'c-', 'linewidth', 1);
            plot([0:160], Value * ones(1,161), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
            plot(Value * ones(1,161), [0:160], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
            NetTmp = NetTmp + 1;
        end
    end
end

axis off;
text(-24.55,15.927,'SubcN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-17.84,45.09,'SMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-16.07,71.59,'FPN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-17.82,99.59,'DMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.20,128.09,'TempN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-19.82,149.59,'OccN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');

text(3.86,166.4,'SubcN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(37.29,166.4,'SMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(64.72,166.4,'FPN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(91.96,166.4,'DMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(115.28,166.4,'TempN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(141.71,166.4,'OccN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');