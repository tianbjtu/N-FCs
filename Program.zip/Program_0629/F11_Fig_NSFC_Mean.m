%% Fig1(A��C��E) 
clear;clc;
ROI_NUM = 160;


%%
%��NSFC��RemFC��PartFC��160*160��PartFC-NSFC�Ĳ�ֵ160*160
%%��������
% %NSFC
% load E:\brainFingerprint\code\FCReliability\Results\SubjInfo184_AgeGendIQ_200506;
%  load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj;

% %PartFC
%load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_12Part_178Subj

%CorrAll = squeeze(mean(CorrMat160,2)); CorrAll = squeeze(mean(CorrAll, 1)); %CorrAll = reshape(CorrAll, ROI_NUM, ROI_NUM);
%CorrMat160 4*178*160*160�����ڸ���ˮƽƽ������4����Ӱƽ����

%%
%�����������
load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj;
CorrAll = squeeze(mean(CorrMat160,2)); CorrAll1 = squeeze(mean(CorrAll, 1));
% %PartFC
load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_12Part_178Subj
CorrAll = squeeze(mean(CorrMat160,2)); CorrAll2 = squeeze(mean(CorrAll, 1));

CorrAllTmp= CorrAll1 - CorrAll2;

%%
%��AP����Ļ���
load E:\brainFingerprint\code\FCReliability\Results\ROI_Net_7to6_200629.mat
NetNo = ROI_160;
%NET_NUM = length(unique(NetNo)); ROI_No_New = [find(NetNo==1); find(NetNo==2); find(NetNo==3); find(NetNo==4); find(NetNo==5); find(NetNo==6)];  % 6������
NET_NUM = length(unique(NetNo)); 
%ROI_No_New =[];

% for i=1:NET_NUM
%    NetNoTemp =  find(NetNo==i);%id
%    len = length(NetNoTemp);
%    halfLen = round(len/2);
%    NetNoTemp1 = NetNoTemp(1:halfLen);
%    NetNoTemp2 = NetNoTemp(halfLen+1:len);
%    tempMatrix1 = CorrAll(NetNoTemp1,NetNoTemp1);%��������Ϊ����
%    tempMatrix2 = CorrAll(NetNoTemp2,NetNoTemp2);
%    sumColumn1 = sum(tempMatrix1);%value
%    sumColumn2 = sum(tempMatrix2);
%     
%    [sumColumn1,id1]  = sort(sumColumn1);
%    [sumColumn2,id2]  = sort(sumColumn2,'descend');
%    NetNoTempNew = NetNoTemp1(id1);
%    NetNoTempNew = [NetNoTempNew;NetNoTemp2(id2)];
%    ROI_No_New = [ROI_No_New;NetNoTempNew];
% end
load  E:\brainFingerprint\code\FCReliability\Results\ROI_No_New.mat     

CorrAll = CorrAllTmp(ROI_No_New, ROI_No_New); 
%CorrAll = CorrAll(ROI_No_New, ROI_No_New); 

figure(1); imagesc(CorrAll);   colorbar(); caxis([-0.01,0.03]);hold on;% caxis([-0.1,1.0]);    colorbar.Ticks = [-0.1;0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1];
colorbar('YTickLabel',{'-0.010','-0.005','0','0.005','0.010','0.015','0.020','0.025','0.030'});

%%
%������ָ���
NetNoUnique = unique(NetNo); NetTmp = 1; 
for Count = 1 : ROI_NUM-1
    if(NetTmp < length(NetNoUnique))
        if(NetNo(ROI_No_New(Count)) == NetNoUnique(NetTmp) && NetNo(ROI_No_New(Count+1)) == NetNoUnique(NetTmp+1))
            Value = Count + 0.5;
            plot([0:160], Value * ones(1,161), 'Color',[0.7 0.7 0.7], 'linewidth', 1);
            plot(Value * ones(1,161), [0:160], 'Color',[0.7 0.7 0.7], 'linewidth', 1);
            NetTmp = NetTmp + 1;
        end
    end
end
axis off;
text(-24.55,15.927,'SubcN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-17.84,45.09,'SMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-16.07,71.59,'FPN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-17.82,99.59,'DMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-25.20,128.09,'TempN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(-19.82,149.59,'OccN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');

text(3.86,166.4,'SubcN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(37.29,166.4,'SMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(64.72,166.4,'FPN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(91.96,166.4,'DMN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(115.28,166.4,'TempN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');
text(141.71,166.4,'OccN','FontSize',12, 'fontname', 'arial', 'fontweight', 'bold');