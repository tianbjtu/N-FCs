clear;
clc;
warning off; 
FOLD_NUM = 10; DIM = 5; ROUND_NUM = 100;

load E:\brainFingerprint\code\FCReliability\Results\SubjInfo178_222Label_200507;
LabelTmp = SubjInfo(:, 2);%2/75 %%%--------Gender 2 Age 220 IQ 38/39 CrystalIQ 40/41 Reading 13/14 PictVoc 15/16 Strength 174/175 
SubjNoUse = find(LabelTmp ~= -9999); Label = LabelTmp(SubjNoUse); SampleSize = length(Label);

load E:\brainFingerprint\code\FCReliability\Results\CorrArray_All4Mov_178Subj; 
CorrMat = CorrMat(:, SubjNoUse, :);

%%
for RoundNo = 1 : ROUND_NUM
    RoundNo
    [TrainNo, TestNo, Permed] = f_NFold(SampleSize, FOLD_NUM);
    for MovNo = 1 : 4
        for FoldNo = 1 : FOLD_NUM
            LabelTrain = Label(TrainNo{FoldNo}, :);
            CorrTrain = squeeze(CorrMat(MovNo, TrainNo{FoldNo}, :));
        
            LabelMean = mean(LabelTrain, 1); 
            CorrMean = mean(CorrTrain, 1);
            [XLOADINGS,YLOADINGS,XSCORES,YSCORES, Beta] = plsregress(CorrTrain, LabelTrain, DIM);
        
            for MovTargNo = 1 : 4
                CorrTest = squeeze(CorrMat(MovTargNo, TestNo{FoldNo}, :)); 
                CorrTest_Norm = CorrTest - repmat(CorrMean, size(CorrTest, 1), 1); 
                B = Beta(2:end, :);
                TestLabel_Pred = CorrTest_Norm * B;
            
                Predicted(RoundNo, MovNo, MovTargNo, TestNo{FoldNo}) = TestLabel_Pred + repmat(LabelMean, size(TestLabel_Pred, 1), 1);
            end 
        end    
    
        %%
        for MovTargNo = 1 : 4
            if (length(unique(int16(Label))) == 2)
                R(RoundNo, MovNo, MovTargNo) = sum(abs((squeeze(Predicted(RoundNo, MovNo, MovTargNo, :)) > 0.5) - Label) < 0.000001) / SampleSize;
            else
                r = corrcoef(squeeze(Predicted(RoundNo, MovNo, MovTargNo, :)), Label);
                R(RoundNo, MovNo, MovTargNo) = r(1,2); 
                RMSE(RoundNo, MovNo, MovTargNo) = sqrt (sum ((squeeze(Predicted(RoundNo, MovNo, MovTargNo, :)) - Label) .^ 2) / (SampleSize-1)); 
            end
        end
    end    
    
    MeanR = squeeze(mean(R, 1))
    StdR = squeeze(std(R, 1));
end

if(length(unique(int16(Label))) == 2)
    save E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Gender R Predicted SubjInfo SubjNoUse MeanR StdR;  
else
    MeanRMSE = squeeze(mean(RMSE, 1));
    StdRMSE = squeeze(std(RMSE, 1));
    save E:\brainFingerprint\code\FCReliability\Results\Pred_PLSR160ROI_Strength R RMSE Predicted SubjInfo SubjNoUse MeanR StdR MeanRMSE StdRMSE ;  %%%--------
end  
