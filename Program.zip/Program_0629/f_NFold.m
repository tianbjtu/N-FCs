function [TrainNo, TestNo, Permed] = f_NFold(SampleSize, FoldNum)
MinFeatNumPerFold = floor(SampleSize/FoldNum);

Permed = randperm (SampleSize);
for Tmp = 1 : FoldNum
    SampleNo{Tmp} = Permed((Tmp-1)*MinFeatNumPerFold+1 : Tmp*MinFeatNumPerFold);
end
if mod(SampleSize, FoldNum)
    for Tmp = 1 : mod(SampleSize, FoldNum)
        SampleNo{Tmp} = [SampleNo{Tmp}, Permed(FoldNum*MinFeatNumPerFold+Tmp)];
    end
end

for Tmp = 1 : FoldNum
    TestNo{Tmp} = SampleNo{Tmp};
    TrainNo{Tmp} = [SampleNo{find([1 : FoldNum] ~= Tmp)}];
end
